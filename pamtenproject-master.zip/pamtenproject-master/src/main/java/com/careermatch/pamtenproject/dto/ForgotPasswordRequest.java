package com.careermatch.pamtenproject.dto;
import lombok.Data;

@Data
public class ForgotPasswordRequest {
    private String email;
}